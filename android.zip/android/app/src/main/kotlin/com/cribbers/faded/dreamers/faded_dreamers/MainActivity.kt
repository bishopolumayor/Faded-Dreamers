package com.cribbers.faded.dreamers.faded_dreamers

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
